import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, FileSpreadsheet, FileText, FileJson, Database, Calendar, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function ExportPage() {
  const [exportConfig, setExportConfig] = useState({
    format: "excel",
    dateFrom: "2025-11-01",
    dateTo: "2025-11-30",
    includeTransactions: true,
    includeCustomers: false,
    includeInvoices: false,
    includeReports: false,
  });

  const exportFormats = [
    { value: "excel", label: "Excel (.xlsx)", icon: FileSpreadsheet, description: "Ideal para análises e gráficos" },
    { value: "csv", label: "CSV (.csv)", icon: FileText, description: "Compatível com diversos sistemas" },
    { value: "pdf", label: "PDF (.pdf)", icon: FileText, description: "Documento formatado e imprimível" },
    { value: "json", label: "JSON (.json)", icon: FileJson, description: "Para integração com sistemas" },
  ];

  const recentExports = [
    { id: 1, name: "Transações - Novembro 2025.xlsx", date: "08/11/2025 10:30", size: "2.5 MB", status: "completed" },
    { id: 2, name: "Relatório DRE - Outubro 2025.pdf", date: "01/11/2025 14:20", size: "890 KB", status: "completed" },
    { id: 3, name: "Clientes - Exportação Completa.csv", date: "25/10/2025 09:15", size: "450 KB", status: "completed" },
  ];

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Exportar Dados
            </h1>
            <p className="text-muted-foreground mt-1">
              Exporte seus dados em diversos formatos para análise e backup
            </p>
          </div>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-3">
          <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurar Exportação</CardTitle>
                <CardDescription>Selecione o formato e os dados que deseja exportar</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Formato de Exportação</Label>
                  <div className="grid gap-3">
                    {exportFormats.map((format) => {
                      const Icon = format.icon;
                      return (
                        <Card 
                          key={format.value}
                          className={`cursor-pointer transition-all ${
                            exportConfig.format === format.value 
                              ? "border-primary ring-2 ring-primary/20" 
                              : "hover:border-primary/50"
                          }`}
                          onClick={() => setExportConfig({ ...exportConfig, format: format.value })}
                        >
                          <CardContent className="pt-6">
                            <div className="flex items-center gap-4">
                              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                                <Icon className="h-6 w-6 text-primary" />
                              </div>
                              <div className="flex-1">
                                <h3 className="font-semibold">{format.label}</h3>
                                <p className="text-sm text-muted-foreground">{format.description}</p>
                              </div>
                              {exportConfig.format === format.value && (
                                <CheckCircle2 className="h-6 w-6 text-primary" />
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dateFrom">Data Inicial</Label>
                    <Input
                      id="dateFrom"
                      type="date"
                      value={exportConfig.dateFrom}
                      onChange={(e) => setExportConfig({ ...exportConfig, dateFrom: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateTo">Data Final</Label>
                    <Input
                      id="dateTo"
                      type="date"
                      value={exportConfig.dateTo}
                      onChange={(e) => setExportConfig({ ...exportConfig, dateTo: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-3 border-t pt-4">
                  <Label>Dados para Exportar</Label>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="transactions"
                          checked={exportConfig.includeTransactions}
                          onCheckedChange={(checked) => setExportConfig({ ...exportConfig, includeTransactions: checked as boolean })}
                        />
                        <label htmlFor="transactions" className="font-medium cursor-pointer">
                          Transações
                        </label>
                      </div>
                      <Badge variant="secondary">1,234 registros</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="customers"
                          checked={exportConfig.includeCustomers}
                          onCheckedChange={(checked) => setExportConfig({ ...exportConfig, includeCustomers: checked as boolean })}
                        />
                        <label htmlFor="customers" className="font-medium cursor-pointer">
                          Clientes
                        </label>
                      </div>
                      <Badge variant="secondary">45 registros</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="invoices"
                          checked={exportConfig.includeInvoices}
                          onCheckedChange={(checked) => setExportConfig({ ...exportConfig, includeInvoices: checked as boolean })}
                        />
                        <label htmlFor="invoices" className="font-medium cursor-pointer">
                          Faturas
                        </label>
                      </div>
                      <Badge variant="secondary">89 registros</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="reports"
                          checked={exportConfig.includeReports}
                          onCheckedChange={(checked) => setExportConfig({ ...exportConfig, includeReports: checked as boolean })}
                        />
                        <label htmlFor="reports" className="font-medium cursor-pointer">
                          Relatórios Financeiros
                        </label>
                      </div>
                      <Badge variant="secondary">DRE, Fluxo de Caixa</Badge>
                    </div>
                  </div>
                </div>

                <Button className="w-full gap-2" size="lg">
                  <Download className="h-5 w-5" />
                  Exportar Agora
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Exportações Agendadas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Programe exportações automáticas para receber seus dados regularmente
                </p>
                <Button variant="outline" className="w-full">
                  Agendar Exportação
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Exportações Recentes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentExports.map((exp) => (
                  <div key={exp.id} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                    <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileSpreadsheet className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm truncate">{exp.name}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-muted-foreground">{exp.date}</span>
                        <span className="text-xs text-muted-foreground">•</span>
                        <span className="text-xs text-muted-foreground">{exp.size}</span>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
              <CardContent className="pt-6">
                <Database className="h-8 w-8 text-blue-600 mb-3" />
                <h3 className="font-semibold mb-2">Backup Completo</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Faça um backup completo de todos os seus dados para segurança
                </p>
                <Button variant="default" className="w-full">
                  Fazer Backup
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </AppLayout>
  );
}
