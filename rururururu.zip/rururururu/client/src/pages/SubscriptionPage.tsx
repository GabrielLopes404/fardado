import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Zap, Star, CreditCard, Calendar, TrendingUp, Download } from "lucide-react";
import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function SubscriptionPage() {
  const currentPlan = {
    name: "Profissional",
    price: 99,
    currency: "R$",
    period: "mês",
    status: "active",
    renewDate: "08/12/2025",
    daysLeft: 30,
  };

  const usage = {
    transactions: { used: 1234, limit: 5000, percentage: 24.7 },
    users: { used: 3, limit: 10, percentage: 30 },
    storage: { used: 2.5, limit: 50, percentage: 5 },
  };

  const paymentHistory = [
    { id: 1, date: "08/11/2025", amount: 99, status: "paid", invoice: "INV-2025-11" },
    { id: 2, date: "08/10/2025", amount: 99, status: "paid", invoice: "INV-2025-10" },
    { id: 3, date: "08/09/2025", amount: 99, status: "paid", invoice: "INV-2025-09" },
    { id: 4, date: "08/08/2025", amount: 99, status: "paid", invoice: "INV-2025-08" },
  ];

  const plans = [
    {
      name: "Básico",
      price: 49,
      features: [
        "Até 1.000 transações/mês",
        "2 usuários",
        "10 GB armazenamento",
        "Relatórios básicos",
        "Suporte por email",
      ],
      icon: Zap,
      color: "blue",
    },
    {
      name: "Profissional",
      price: 99,
      features: [
        "Até 5.000 transações/mês",
        "10 usuários",
        "50 GB armazenamento",
        "Relatórios avançados",
        "Suporte prioritário",
        "Exportação ilimitada",
      ],
      icon: Crown,
      color: "purple",
      popular: true,
    },
    {
      name: "Empresarial",
      price: 199,
      features: [
        "Transações ilimitadas",
        "Usuários ilimitados",
        "200 GB armazenamento",
        "Todos os relatórios",
        "Suporte 24/7",
        "API personalizada",
        "Gerente de conta dedicado",
      ],
      icon: Star,
      color: "orange",
    },
  ];

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Minha Assinatura
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie sua assinatura e histórico de pagamentos
            </p>
          </div>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 bg-white/20 rounded-full flex items-center justify-center">
                    <Crown className="h-8 w-8" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">Plano {currentPlan.name}</h2>
                    <p className="opacity-90 mt-1">
                      {currentPlan.currency} {currentPlan.price}/{currentPlan.period}
                    </p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button variant="secondary" className="gap-2">
                    <TrendingUp className="h-4 w-4" />
                    Fazer Upgrade
                  </Button>
                  <Button variant="outline" className="bg-white/10 border-white/20 hover:bg-white/20 text-white">
                    Cancelar Plano
                  </Button>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-white/20 grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm opacity-75">Status</p>
                  <Badge className="mt-1 bg-green-500 hover:bg-green-600">Ativo</Badge>
                </div>
                <div>
                  <p className="text-sm opacity-75">Próxima cobrança</p>
                  <p className="font-semibold mt-1">{currentPlan.renewDate}</p>
                </div>
                <div>
                  <p className="text-sm opacity-75">Dias restantes</p>
                  <p className="font-semibold mt-1">{currentPlan.daysLeft} dias</p>
                </div>
                <div>
                  <p className="text-sm opacity-75">Método de pagamento</p>
                  <div className="flex items-center gap-2 mt-1">
                    <CreditCard className="h-4 w-4" />
                    <span className="font-semibold">•••• 4242</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Uso do Plano</CardTitle>
              <CardDescription>Acompanhe seu consumo mensal</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Transações</span>
                  <span className="text-sm text-muted-foreground">
                    {usage.transactions.used.toLocaleString()} / {usage.transactions.limit.toLocaleString()}
                  </span>
                </div>
                <Progress value={usage.transactions.percentage} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {usage.transactions.percentage.toFixed(1)}% utilizado
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Usuários</span>
                  <span className="text-sm text-muted-foreground">
                    {usage.users.used} / {usage.users.limit}
                  </span>
                </div>
                <Progress value={usage.users.percentage} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {usage.users.percentage.toFixed(1)}% utilizado
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Armazenamento</span>
                  <span className="text-sm text-muted-foreground">
                    {usage.storage.used} GB / {usage.storage.limit} GB
                  </span>
                </div>
                <Progress value={usage.storage.percentage} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {usage.storage.percentage.toFixed(1)}% utilizado
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Histórico de Pagamentos</CardTitle>
                <Button variant="outline" size="sm" className="gap-2">
                  <Download className="h-4 w-4" />
                  Exportar
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Fatura</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paymentHistory.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell className="font-medium">{payment.date}</TableCell>
                      <TableCell>{payment.invoice}</TableCell>
                      <TableCell>
                        R$ {payment.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-green-500 hover:bg-green-600">
                          Pago
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Download className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Comparar Planos</CardTitle>
              <CardDescription>Veja todos os planos disponíveis e faça upgrade</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                {plans.map((plan) => {
                  const Icon = plan.icon;
                  const isCurrentPlan = plan.name === currentPlan.name;
                  return (
                    <Card key={plan.name} className={`relative ${isCurrentPlan ? "border-primary ring-2 ring-primary/20" : ""}`}>
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white border-0 shadow-lg flex items-center gap-1 px-3 py-1">
                            <Star className="h-3 w-3 fill-current" />
                            Mais Popular
                          </Badge>
                        </div>
                      )}
                      <CardContent className="pt-6">
                        <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                        <h3 className="text-2xl font-bold">{plan.name}</h3>
                        <div className="mt-2 mb-6">
                          <span className="text-4xl font-bold">R$ {plan.price}</span>
                          <span className="text-muted-foreground">/mês</span>
                        </div>
                        <ul className="space-y-3 mb-6">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                              <span className="text-sm">{feature}</span>
                            </li>
                          ))}
                        </ul>
                        <Button 
                          className="w-full" 
                          variant={isCurrentPlan ? "outline" : "default"}
                          disabled={isCurrentPlan}
                        >
                          {isCurrentPlan ? "Plano Atual" : "Selecionar Plano"}
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
