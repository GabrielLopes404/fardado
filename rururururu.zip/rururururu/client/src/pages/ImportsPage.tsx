import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, Upload, FileText, Users, Download } from "lucide-react";
import { motion } from "framer-motion";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function ImportsPage() {
  const importTypes = [
    {
      icon: FileSpreadsheet,
      title: "Importação padrão",
      description: "Importação de dados simples, utilizando o nosso formato",
      badge: null,
    },
    {
      icon: FileText,
      title: "Zero Paper",
      description: "Importação de dados utilizando o Excel do Zero Paper",
      badge: null,
    },
    {
      icon: Users,
      title: "Contatos",
      description: "Importação de contatos, utilizando o Excel",
      badge: null,
    },
    {
      icon: FileSpreadsheet,
      title: "OFX",
      description: "Importação de dados utilizando o formato de arquivo OFX",
      badge: null,
    },
  ];

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">Importações</h1>
            <p className="text-muted-foreground mt-1">
              Importe dados de diferentes fontes
            </p>
          </div>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar Histórico
          </Button>
        </motion.div>

        <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {importTypes.map((type, index) => {
            const Icon = type.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ y: -4 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Card className="hover:shadow-xl transition-shadow cursor-pointer group h-full border-border/50 hover:border-primary/30">
                  <CardHeader>
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 group-hover:from-primary/20 group-hover:to-primary/10 transition-all">
                        <Icon className="h-8 w-8 text-primary" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          {type.title}
                          {type.badge && (
                            <Badge variant="secondary">{type.badge}</Badge>
                          )}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground mt-2">
                          {type.description}
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full gap-2 shadow-lg shadow-primary/20">
                      <Upload className="h-4 w-4" />
                      Importar
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle>Histórico de Importações</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <div className="mb-4 inline-flex p-4 rounded-full bg-primary/10">
                  <FileSpreadsheet className="h-12 w-12 text-primary" />
                </div>
                <p className="text-lg font-semibold text-foreground">Nenhuma importação realizada ainda</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Importar arquivo externo
                </p>
                <p className="text-sm text-muted-foreground">
                  Clique em uma das opções acima para realizar a primeira importação
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
