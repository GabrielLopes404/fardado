import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Loader2, Calendar, DollarSign, FileText, Search, Filter, X, ArrowUpDown, CheckCircle2, Clock, AlertCircle, XCircle, File } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";

interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  description: string | null;
  amount: string;
  status: "draft" | "pending" | "paid" | "overdue" | "canceled";
  dueDate: string | null;
  paidDate: string | null;
  issueDate: string;
  notes: string | null;
  createdAt: string;
}

interface Customer {
  id: string;
  name: string;
  email: string;
}

const statusConfig = {
  draft: { 
    label: "Rascunho", 
    color: "bg-gray-500/10 text-gray-700 border-gray-500/20",
    icon: File,
    gradient: "from-gray-500 to-gray-600"
  },
  pending: { 
    label: "Pendente", 
    color: "bg-orange-500/10 text-orange-700 border-orange-500/20",
    icon: Clock,
    gradient: "from-orange-500 to-amber-600"
  },
  paid: { 
    label: "Paga", 
    color: "bg-green-500/10 text-green-700 border-green-500/20",
    icon: CheckCircle2,
    gradient: "from-green-500 to-emerald-600"
  },
  overdue: { 
    label: "Vencida", 
    color: "bg-red-500/10 text-red-700 border-red-500/20",
    icon: AlertCircle,
    gradient: "from-red-500 to-rose-600"
  },
  canceled: { 
    label: "Cancelada", 
    color: "bg-gray-400/10 text-gray-600 border-gray-400/20",
    icon: XCircle,
    gradient: "from-gray-400 to-gray-500"
  },
};

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function InvoicesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [deleteInvoiceId, setDeleteInvoiceId] = useState<string | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<Invoice["status"] | "all">("all");
  const [sortBy, setSortBy] = useState<"invoiceNumber" | "amount" | "dueDate" | "createdAt">("createdAt");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [formData, setFormData] = useState({
    customerId: "",
    description: "",
    amount: "",
    status: "draft" as Invoice["status"],
    dueDate: "",
    notes: "",
  });

  const { data: invoices, isLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
    queryFn: async () => {
      const res = await fetch("/api/invoices", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch invoices");
      return res.json();
    },
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
    queryFn: async () => {
      const res = await fetch("/api/customers", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch customers");
      return res.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create invoice");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      toast({ 
        variant: "success",
        title: "Fatura criada com sucesso!",
        description: "A fatura foi adicionada ao sistema."
      });
      setIsCreateOpen(false);
      resetForm();
    },
    onError: () => {
      toast({ 
        variant: "destructive", 
        title: "Erro ao criar fatura",
        description: "Tente novamente mais tarde."
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const res = await fetch(`/api/invoices/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update invoice");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      toast({ 
        variant: "success",
        title: "Fatura atualizada!",
        description: "As informações foram salvas."
      });
      setIsEditOpen(false);
      setSelectedInvoice(null);
      resetForm();
    },
    onError: () => {
      toast({ 
        variant: "destructive", 
        title: "Erro ao atualizar fatura" 
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/invoices/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete invoice");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      toast({ 
        variant: "info",
        title: "Fatura deletada!",
        description: "A fatura foi removida do sistema."
      });
      setDeleteInvoiceId(null);
    },
    onError: () => {
      toast({ 
        variant: "destructive", 
        title: "Erro ao deletar fatura" 
      });
    },
  });

  const resetForm = () => {
    setFormData({
      customerId: "",
      description: "",
      amount: "",
      status: "draft",
      dueDate: "",
      notes: "",
    });
  };

  const handleCreate = () => {
    resetForm();
    setIsCreateOpen(true);
  };

  const handleEdit = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setFormData({
      customerId: invoice.customerId,
      description: invoice.description || "",
      amount: invoice.amount,
      status: invoice.status,
      dueDate: invoice.dueDate || "",
      notes: invoice.notes || "",
    });
    setIsEditOpen(true);
  };

  const handleDeleteClick = (id: string) => {
    setDeleteInvoiceId(id);
  };

  const handleDeleteConfirm = () => {
    if (deleteInvoiceId) {
      deleteMutation.mutate(deleteInvoiceId);
    }
  };

  const getCustomerName = (customerId: string) => {
    return customers?.find(c => c.id === customerId)?.name || "Cliente não encontrado";
  };

  const filteredInvoices = invoices
    ?.filter((invoice) => {
      const matchesSearch = !searchTerm || (
        invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        getCustomerName(invoice.customerId).toLowerCase().includes(searchTerm.toLowerCase())
      );

      const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;

      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      let compareValue = 0;
      
      if (sortBy === "invoiceNumber") {
        compareValue = a.invoiceNumber.localeCompare(b.invoiceNumber);
      } else if (sortBy === "amount") {
        compareValue = Number(a.amount) - Number(b.amount);
      } else if (sortBy === "dueDate") {
        const aDate = a.dueDate ? new Date(a.dueDate).getTime() : 0;
        const bDate = b.dueDate ? new Date(b.dueDate).getTime() : 0;
        compareValue = aDate - bDate;
      } else if (sortBy === "createdAt") {
        compareValue = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      }

      return sortOrder === "asc" ? compareValue : -compareValue;
    });

  const stats = {
    total: invoices?.length || 0,
    draft: invoices?.filter(i => i.status === "draft").length || 0,
    pending: invoices?.filter(i => i.status === "pending").length || 0,
    paid: invoices?.filter(i => i.status === "paid").length || 0,
    overdue: invoices?.filter(i => i.status === "overdue").length || 0,
    totalAmount: invoices?.reduce((sum, inv) => sum + Number(inv.amount), 0) || 0,
    paidAmount: invoices?.filter(i => i.status === "paid").reduce((sum, inv) => sum + Number(inv.amount), 0) || 0,
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "-";
    return new Date(dateString).toLocaleDateString("pt-BR");
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-violet-600 via-purple-600 to-cyan-600 bg-clip-text text-transparent">
              Faturas
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">
              Gerencie suas faturas e cobranças
            </p>
          </div>
          <Button onClick={handleCreate} size="lg" className="gap-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 shadow-lg">
            <Plus className="h-5 w-5" />
            <span className="hidden sm:inline">Nova Fatura</span>
            <span className="sm:hidden">Nova</span>
          </Button>
        </motion.div>

        {/* Stats Cards */}
        <motion.div variants={itemVariants} className="grid gap-4 grid-cols-2 sm:grid-cols-3 lg:grid-cols-5">
          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-violet-500/20 hover:border-violet-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-violet-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-violet-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground">Total</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg">
                    <FileText className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                  </div>
                  <div className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                    {stats.total}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-green-500/20 hover:border-green-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-green-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-green-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground">Pagas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg">
                    <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                  </div>
                  <div className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    {stats.paid}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-orange-500/20 hover:border-orange-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-orange-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-orange-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground">Pendentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-lg bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center shadow-lg">
                    <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                  </div>
                  <div className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                    {stats.pending}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-red-500/20 hover:border-red-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-red-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-red-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground">Vencidas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-lg bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center shadow-lg">
                    <AlertCircle className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                  </div>
                  <div className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">
                    {stats.overdue}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-cyan-500/20 hover:border-cyan-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-cyan-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-cyan-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground">Recebido</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <div className="text-lg sm:text-xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
                    {formatCurrency(stats.paidAmount)}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    de {formatCurrency(stats.totalAmount)}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Search and Filters */}
        <motion.div variants={itemVariants}>
          <Card className="shadow-xl border-border/50">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Buscar por número, cliente ou descrição..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="flex gap-2">
                    {searchTerm && (
                      <Button variant="outline" size="icon" onClick={() => setSearchTerm("")}>
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {/* Status Filters */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Status:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={statusFilter === "all" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setStatusFilter("all")}
                      className={statusFilter === "all" ? "bg-gradient-to-r from-violet-600 to-purple-600" : ""}
                    >
                      Todas ({stats.total})
                    </Button>
                    {Object.entries(statusConfig).map(([status, config]) => {
                      const Icon = config.icon;
                      const count = stats[status as keyof typeof stats] as number;
                      return (
                        <Button
                          key={status}
                          variant={statusFilter === status ? "default" : "outline"}
                          size="sm"
                          onClick={() => setStatusFilter(status as Invoice["status"])}
                          className={statusFilter === status ? `bg-gradient-to-r ${config.gradient}` : ""}
                        >
                          <Icon className="h-3 w-3 mr-1" />
                          {config.label} ({count})
                        </Button>
                      );
                    })}
                  </div>
                </div>

                {/* Sorting */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                    <ArrowUpDown className="h-4 w-4" />
                    Ordenar:
                  </span>
                  <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                    <SelectTrigger className="w-[180px] h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="createdAt">Data de Criação</SelectItem>
                      <SelectItem value="invoiceNumber">Número</SelectItem>
                      <SelectItem value="amount">Valor</SelectItem>
                      <SelectItem value="dueDate">Vencimento</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
                  >
                    {sortOrder === "asc" ? "Crescente ↑" : "Decrescente ↓"}
                  </Button>
                </div>

                {/* Active Filters */}
                {(searchTerm || statusFilter !== "all") && (
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="text-muted-foreground">Filtros ativos:</span>
                    {searchTerm && (
                      <div className="px-3 py-1 bg-violet-500/10 text-violet-600 rounded-full flex items-center gap-2">
                        <span>Busca: "{searchTerm}"</span>
                        <button onClick={() => setSearchTerm("")} className="hover:text-violet-800">
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    )}
                    {statusFilter !== "all" && (
                      <div className="px-3 py-1 bg-cyan-500/10 text-cyan-600 rounded-full flex items-center gap-2">
                        <span>{statusConfig[statusFilter].label}</span>
                        <button onClick={() => setStatusFilter("all")} className="hover:text-cyan-800">
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSearchTerm("");
                        setStatusFilter("all");
                      }}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      Limpar todos
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Table */}
        <motion.div variants={itemVariants}>
          <Card className="shadow-xl border-border/50 overflow-hidden">
            {isLoading ? (
              <div className="flex items-center justify-center p-12 sm:p-20">
                <div className="text-center space-y-4">
                  <Loader2 className="h-12 w-12 animate-spin text-violet-500 mx-auto" />
                  <p className="text-muted-foreground">Carregando faturas...</p>
                </div>
              </div>
            ) : filteredInvoices && filteredInvoices.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="font-bold">Número</TableHead>
                      <TableHead className="font-bold hidden sm:table-cell">Cliente</TableHead>
                      <TableHead className="font-bold">Valor</TableHead>
                      <TableHead className="font-bold hidden md:table-cell">Vencimento</TableHead>
                      <TableHead className="font-bold">Status</TableHead>
                      <TableHead className="text-right font-bold">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <AnimatePresence>
                      {filteredInvoices.map((invoice, index) => {
                        const config = statusConfig[invoice.status];
                        const Icon = config.icon;
                        return (
                          <motion.tr
                            key={invoice.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20 }}
                            transition={{ delay: index * 0.03 }}
                            className="group hover:bg-muted/50 transition-colors"
                          >
                            <TableCell className="font-mono font-semibold">
                              <div className="flex items-center gap-2">
                                <FileText className="h-4 w-4 text-violet-500" />
                                {invoice.invoiceNumber}
                              </div>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell">
                              <span className="truncate max-w-[200px] block">{getCustomerName(invoice.customerId)}</span>
                            </TableCell>
                            <TableCell>
                              <div className="font-bold text-foreground">
                                {formatCurrency(Number(invoice.amount))}
                              </div>
                            </TableCell>
                            <TableCell className="hidden md:table-cell">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                                {formatDate(invoice.dueDate)}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={`${config.color} border font-semibold`}>
                                <Icon className="h-3 w-3 mr-1" />
                                {config.label}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-1 sm:gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 hover:bg-violet-500/10 hover:text-violet-600"
                                  onClick={() => handleEdit(invoice)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 hover:bg-red-500/10 hover:text-red-600"
                                  onClick={() => handleDeleteClick(invoice.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </motion.tr>
                        );
                      })}
                    </AnimatePresence>
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-12 sm:py-20 px-4">
                <div className="inline-flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-full bg-gradient-to-br from-violet-500/10 to-purple-500/10 mb-4">
                  <FileText className="h-8 w-8 sm:h-10 sm:w-10 text-violet-500" />
                </div>
                <h3 className="text-lg sm:text-xl font-semibold mb-2">Nenhuma fatura encontrada</h3>
                <p className="text-sm sm:text-base text-muted-foreground mb-6">
                  {searchTerm || statusFilter !== "all" ? "Tente ajustar os filtros de busca" : "Comece criando sua primeira fatura"}
                </p>
                <Button onClick={handleCreate} size="lg" className="gap-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                  <Plus className="h-5 w-5" />
                  Criar Primeira Fatura
                </Button>
              </div>
            )}
          </Card>
        </motion.div>
      </motion.div>

      {/* Create Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              Nova Fatura
            </DialogTitle>
            <DialogDescription>
              Preencha as informações da fatura. Campos marcados com * são obrigatórios.
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              createMutation.mutate(formData);
            }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="customerId" className="text-sm font-semibold">
                Cliente <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.customerId}
                onValueChange={(value) => setFormData({ ...formData, customerId: value })}
                required
              >
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Selecione um cliente" />
                </SelectTrigger>
                <SelectContent>
                  {customers?.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name} ({customer.email})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-sm font-semibold">
                  Valor <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dueDate" className="text-sm font-semibold">Data de Vencimento</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  className="h-11"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status" className="text-sm font-semibold">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: Invoice["status"]) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(statusConfig).map(([status, config]) => (
                    <SelectItem key={status} value={status}>
                      {config.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-sm font-semibold">Descrição</Label>
              <Textarea
                id="description"
                placeholder="Descreva os serviços ou produtos..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-sm font-semibold">Observações</Label>
              <Textarea
                id="notes"
                placeholder="Adicione observações sobre a fatura..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="resize-none"
              />
            </div>

            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={createMutation.isPending}
                className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
              >
                {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Criar Fatura
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              Editar Fatura
            </DialogTitle>
            <DialogDescription>
              Atualize as informações da fatura.
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (selectedInvoice) {
                updateMutation.mutate({ id: selectedInvoice.id, data: formData });
              }
            }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="edit-customerId" className="text-sm font-semibold">
                Cliente <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.customerId}
                onValueChange={(value) => setFormData({ ...formData, customerId: value })}
                required
              >
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {customers?.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name} ({customer.email})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-amount" className="text-sm font-semibold">
                  Valor <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="edit-amount"
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-dueDate" className="text-sm font-semibold">Data de Vencimento</Label>
                <Input
                  id="edit-dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  className="h-11"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-status" className="text-sm font-semibold">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: Invoice["status"]) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(statusConfig).map(([status, config]) => (
                    <SelectItem key={status} value={status}>
                      {config.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-description" className="text-sm font-semibold">Descrição</Label>
              <Textarea
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-notes" className="text-sm font-semibold">Observações</Label>
              <Textarea
                id="edit-notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="resize-none"
              />
            </div>

            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setIsEditOpen(false)}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={updateMutation.isPending}
                className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
              >
                {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteInvoiceId} onOpenChange={() => setDeleteInvoiceId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-2xl">Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription className="text-base">
              Tem certeza que deseja deletar esta fatura? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Sim, deletar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
