# Database Migrations Guide

## Overview

This project uses Drizzle ORM for database schema management. There are two approaches:

1. **Push Mode** (Development): `npm run db:push` - Quick schema sync
2. **Migration Mode** (Production): `npm run db:generate` + `npm run db:migrate` - Versioned migrations

## Migration Workflow

### Development (Push Mode)

For rapid development:

```bash
# 1. Update schema in shared/schema.ts
# 2. Push changes directly to database
npm run db:push

# If conflicts, force push (careful!)
npm run db:push --force
```

**When to use:** Local development, quick iterations

**When NOT to use:** Production deployments, team collaboration

### Production (Migration Mode)

For production and team collaboration:

```bash
# 1. Update schema in shared/schema.ts

# 2. Generate migration SQL
npm run db:generate

# This creates a new file in migrations/ folder
# Example: migrations/0001_fluffy_captain_america.sql

# 3. Review the generated SQL
cat migrations/0001_*.sql

# 4. Apply migration
npm run db:migrate

# Migration is tracked in __drizzle_migrations table
```

**When to use:** Production, staging, team collaboration

### Migration Best Practices

1. **Always review generated SQL** before applying
2. **Test in staging first** before production
3. **Backup database** before running migrations
4. **Never edit** migrations after they're applied
5. **Version control** all migration files

## Common Migration Scenarios

### Adding a New Table

```typescript
// shared/schema.ts
export const newTable = pgTable("new_table", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});
```

```bash
npm run db:generate
# Review migrations/0002_*.sql
npm run db:migrate
```

### Adding a Column

```typescript
// Add column to existing table
export const users = pgTable("users", {
  // ... existing columns
  phoneNumber: varchar("phone_number", { length: 20 }), // New column
});
```

```bash
npm run db:generate
# Review: ALTER TABLE users ADD COLUMN phone_number
npm run db:migrate
```

### Renaming a Column

**Warning:** Renames can be destructive!

```typescript
// Option 1: Rename (risky)
export const users = pgTable("users", {
  fullName: varchar("full_name"), // was "name"
});

// Option 2: Add new, migrate data, drop old (safer)
// Step 1: Add new column
export const users = pgTable("users", {
  name: varchar("name"), // old
  fullName: varchar("full_name"), // new
});
```

### Adding an Index

```typescript
export const transactions = pgTable("transactions", {
  // ... columns
}, (table) => ({
  dateIdx: index("transactions_date_idx").on(table.date),
  typeIdx: index("transactions_type_idx").on(table.type),
}));
```

### Adding Foreign Key

```typescript
export const invoices = pgTable("invoices", {
  customerId: varchar("customer_id").references(() => customers.id),
});
```

## Rollback Strategy

Drizzle doesn't have built-in rollback, but you can:

### Option 1: Manual Rollback SQL

Create a down migration manually:

```sql
-- migrations/0002_add_phone_number_down.sql
ALTER TABLE users DROP COLUMN phone_number;
```

### Option 2: Database Restore

```bash
# Restore from backup
psql $DATABASE_URL < backup_before_migration.sql
```

### Option 3: Git Revert + Fresh Migration

```bash
# 1. Revert schema changes
git revert HEAD

# 2. Generate new migration to undo changes
npm run db:generate

# 3. Apply
npm run db:migrate
```

## Zero-Downtime Migrations

For production with zero downtime:

### Adding a Column

```typescript
// Step 1: Add nullable column
export const users = pgTable("users", {
  phoneNumber: varchar("phone_number"), // nullable
});

// Deploy and migrate
npm run db:generate && npm run db:migrate

// Step 2: Backfill data
// UPDATE users SET phone_number = '';

// Step 3: Make column NOT NULL
export const users = pgTable("users", {
  phoneNumber: varchar("phone_number").notNull(),
});

// Deploy and migrate
npm run db:generate && npm run db:migrate
```

### Renaming a Column

```typescript
// Step 1: Add new column
export const users = pgTable("users", {
  name: varchar("name"),
  fullName: varchar("full_name"),
});

// Migrate + Deploy code that writes to both

// Step 2: Backfill
// UPDATE users SET full_name = name;

// Step 3: Switch reads to new column

// Step 4: Drop old column
export const users = pgTable("users", {
  fullName: varchar("full_name"),
});
```

## Migration Checklist

Before running migration in production:

- [ ] Review generated SQL
- [ ] Backup database
- [ ] Test in staging
- [ ] Estimate migration duration
- [ ] Plan rollback strategy
- [ ] Schedule during low-traffic window
- [ ] Monitor during and after migration
- [ ] Verify application still works

## Troubleshooting

### Migration Stuck

```bash
# Check running queries
psql $DATABASE_URL -c "
  SELECT pid, now() - pg_stat_activity.query_start AS duration, query
  FROM pg_stat_activity
  WHERE state != 'idle'
  ORDER BY duration DESC;
"

# Kill stuck migration (if safe)
psql $DATABASE_URL -c "SELECT pg_cancel_backend(<pid>);"
```

### Migration Failed

```bash
# Check migration status
psql $DATABASE_URL -c "SELECT * FROM __drizzle_migrations ORDER BY created_at DESC;"

# Check database logs
docker logs lucrei-db --tail 100

# Restore from backup if needed
```

### Schema Drift

If schema.ts doesn't match database:

```bash
# Option 1: Force push (development only)
npm run db:push --force

# Option 2: Pull schema from DB (future feature)
# npm run db:pull

# Option 3: Manual fix
# Compare schema.ts with actual database
psql $DATABASE_URL -c "\d+ table_name"
```

## CI/CD Integration

### GitHub Actions

```yaml
- name: Run migrations
  run: npm run db:migrate
  env:
    DATABASE_URL: ${{ secrets.DATABASE_URL }}
```

### Docker Deployment

```dockerfile
# Run migrations during container startup
CMD npm run db:migrate && npm start
```

## Monitoring Migrations

### Track Migration History

```sql
SELECT * FROM __drizzle_migrations
ORDER BY created_at DESC;
```

### Monitor Performance

```sql
-- Slow migrations indicator
SELECT 
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size,
  n_tup_ins, n_tup_upd, n_tup_del
FROM pg_stat_user_tables
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

## Best Practices Summary

1. ✅ **Use migrations in production**, not push
2. ✅ **Always review** generated SQL
3. ✅ **Test in staging** first
4. ✅ **Backup before** migrating
5. ✅ **Monitor during** migration
6. ✅ **Have rollback plan** ready
7. ✅ **Version control** migrations
8. ✅ **Document** complex migrations
9. ✅ **Use indexes** for large tables
10. ✅ **Plan zero-downtime** for critical changes

---

**Last Updated:** November 4, 2025
