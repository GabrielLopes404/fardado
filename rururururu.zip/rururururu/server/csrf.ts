import { Request, Response, NextFunction } from 'express';
import { randomBytes } from 'crypto';

export function generateCsrfToken(): string {
  return randomBytes(32).toString('hex');
}

export function csrfProtection(req: Request, res: Response, next: NextFunction) {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    return next();
  }

  const token = req.headers['x-csrf-token'] as string;
  const cookieToken = req.cookies?.csrf_token;

  if (!token || !cookieToken || token !== cookieToken) {
    return res.status(403).json({ 
      message: 'Invalid CSRF token',
      error: 'CSRF_INVALID_TOKEN'
    });
  }

  next();
}

export function setCsrfToken(req: Request, res: Response, next: NextFunction) {
  if (!req.cookies?.csrf_token) {
    const token = generateCsrfToken();
    res.cookie('csrf_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000
    });
  }
  next();
}

export function getCsrfToken(req: Request, res: Response) {
  let token = req.cookies?.csrf_token;
  
  if (!token) {
    token = generateCsrfToken();
    res.cookie('csrf_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000
    });
  }

  res.json({ csrfToken: token });
}
