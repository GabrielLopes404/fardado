import { Request, Response } from 'express';
import { db } from './db';
import { sql } from 'drizzle-orm';

interface HealthCheck {
  status: 'healthy' | 'unhealthy' | 'degraded';
  timestamp: string;
  uptime: number;
  version: string;
  environment: string;
  checks: {
    database: {
      status: 'up' | 'down';
      latency?: number;
      error?: string;
    };
    memory: {
      status: 'ok' | 'warning' | 'critical';
      usage: {
        rss: number;
        heapTotal: number;
        heapUsed: number;
        heapPercentage: number;
      };
    };
    system: {
      platform: string;
      nodeVersion: string;
      pid: number;
    };
  };
}

// Database health check
async function checkDatabase(): Promise<HealthCheck['checks']['database']> {
  try {
    const start = Date.now();
    
    // Simple query to check database connectivity
    await db.execute(sql`SELECT 1`);
    
    const latency = Date.now() - start;
    
    return {
      status: 'up',
      latency
    };
  } catch (error) {
    return {
      status: 'down',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

// Memory health check
function checkMemory(): HealthCheck['checks']['memory'] {
  const usage = process.memoryUsage();
  const heapPercentage = (usage.heapUsed / usage.heapTotal) * 100;
  
  let status: 'ok' | 'warning' | 'critical' = 'ok';
  
  if (heapPercentage > 90) {
    status = 'critical';
  } else if (heapPercentage > 75) {
    status = 'warning';
  }
  
  return {
    status,
    usage: {
      rss: usage.rss,
      heapTotal: usage.heapTotal,
      heapUsed: usage.heapUsed,
      heapPercentage: Math.round(heapPercentage)
    }
  };
}

// System info
function getSystemInfo(): HealthCheck['checks']['system'] {
  return {
    platform: process.platform,
    nodeVersion: process.version,
    pid: process.pid
  };
}

// Main health check endpoint
export async function healthCheck(req: Request, res: Response): Promise<void> {
  try {
    const [databaseCheck] = await Promise.all([
      checkDatabase(),
    ]);
    
    const memoryCheck = checkMemory();
    const systemInfo = getSystemInfo();
    
    // Determine overall status
    let overallStatus: 'healthy' | 'unhealthy' | 'degraded' = 'healthy';
    
    if (databaseCheck.status === 'down') {
      overallStatus = 'unhealthy';
    } else if (memoryCheck.status === 'critical') {
      overallStatus = 'unhealthy';
    } else if (memoryCheck.status === 'warning') {
      overallStatus = 'degraded';
    }
    
    const health: HealthCheck = {
      status: overallStatus,
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      checks: {
        database: databaseCheck,
        memory: memoryCheck,
        system: systemInfo
      }
    };
    
    // Return appropriate HTTP status code
    const statusCode = overallStatus === 'healthy' ? 200 : 
                      overallStatus === 'degraded' ? 200 : 503;
    
    res.status(statusCode).json(health);
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Health check failed'
    });
  }
}

// Simple liveness probe (for Kubernetes)
export function liveness(req: Request, res: Response): void {
  res.status(200).json({ status: 'alive' });
}

// Readiness probe (for Kubernetes)
export async function readiness(req: Request, res: Response): Promise<void> {
  try {
    const dbCheck = await checkDatabase();
    
    if (dbCheck.status === 'up') {
      res.status(200).json({ status: 'ready' });
    } else {
      res.status(503).json({ status: 'not_ready', reason: 'database_down' });
    }
  } catch (error) {
    res.status(503).json({ 
      status: 'not_ready', 
      reason: error instanceof Error ? error.message : 'unknown' 
    });
  }
}
