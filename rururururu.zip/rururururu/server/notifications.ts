import { sendEmail } from "./email";
import { storage } from "./storage";
import type { Invoice, User } from "@shared/schema";

export async function sendInvoiceCreatedNotification(invoice: Invoice, customer: any) {
  const subject = `Nova Fatura #${invoice.invoiceNumber}`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #4F46E5;">Nova Fatura Criada</h2>
      <p>Uma nova fatura foi criada para você:</p>
      
      <div style="background: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p><strong>Número:</strong> #${invoice.invoiceNumber}</p>
        <p><strong>Valor:</strong> R$ ${parseFloat(invoice.amount).toFixed(2)}</p>
        <p><strong>Vencimento:</strong> ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString('pt-BR') : 'Não especificado'}</p>
        <p><strong>Status:</strong> ${invoice.status.toUpperCase()}</p>
      </div>
      
      ${invoice.description ? `<p><strong>Descrição:</strong> ${invoice.description}</p>` : ''}
      
      <p style="margin-top: 30px; color: #6B7280;">
        Este é um email automático do sistema LUCREI.
      </p>
    </div>
  `;

  await sendEmail({ to: customer.email, subject, html });
}

export async function sendInvoicePaidNotification(invoice: Invoice, organizationId: string) {
  const org = await storage.getOrganization(organizationId);
  const users = await storage.getUsersByOrganization(organizationId);
  
  const subject = `Fatura #${invoice.invoiceNumber} Paga`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #10B981;">Pagamento Recebido!</h2>
      <p>A fatura #${invoice.invoiceNumber} foi marcada como paga.</p>
      
      <div style="background: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p><strong>Valor:</strong> R$ ${parseFloat(invoice.amount).toFixed(2)}</p>
        <p><strong>Data:</strong> ${new Date().toLocaleDateString('pt-BR')}</p>
      </div>
      
      <p style="margin-top: 30px; color: #6B7280;">
        Sistema LUCREI - ${org?.name || 'Sua Organização'}
      </p>
    </div>
  `;

  for (const user of users) {
    if (user.role === 'OWNER' || user.role === 'ADMIN') {
      await sendEmail({ to: user.email, subject, html });
    }
  }
}

export async function sendInvoiceOverdueNotification(invoice: Invoice, customer: any) {
  const subject = `Fatura #${invoice.invoiceNumber} Vencida`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #EF4444;">Fatura Vencida</h2>
      <p>A fatura #${invoice.invoiceNumber} está vencida.</p>
      
      <div style="background: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p><strong>Número:</strong> #${invoice.invoiceNumber}</p>
        <p><strong>Valor:</strong> R$ ${parseFloat(invoice.amount).toFixed(2)}</p>
        <p><strong>Vencimento:</strong> ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString('pt-BR') : 'N/A'}</p>
      </div>
      
      <p>Por favor, regularize sua situação o mais breve possível.</p>
      
      <p style="margin-top: 30px; color: #6B7280;">
        Sistema LUCREI
      </p>
    </div>
  `;

  await sendEmail({ to: customer.email, subject, html });
}

export async function sendWeeklyReportNotification(organizationId: string) {
  const org = await storage.getOrganization(organizationId);
  const users = await storage.getUsersByOrganization(organizationId);
  const metrics = await storage.getMetrics(organizationId);
  
  const subject = `Relatório Semanal - ${org?.name}`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #4F46E5;">Relatório Semanal</h2>
      <p>Resumo da semana para ${org?.name}:</p>
      
      <div style="background: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3>Métricas</h3>
        <p><strong>Total de Clientes:</strong> ${metrics.totalCustomers}</p>
        <p><strong>Faturas Emitidas:</strong> ${metrics.totalInvoices}</p>
        <p><strong>Receita Total:</strong> R$ ${parseFloat(metrics.totalRevenue).toFixed(2)}</p>
        <p><strong>Faturas Pagas:</strong> ${metrics.paidInvoices}</p>
        <p><strong>Faturas Pendentes:</strong> ${metrics.pendingInvoices}</p>
        <p><strong>Faturas Vencidas:</strong> ${metrics.overdueInvoices}</p>
      </div>
      
      <p style="margin-top: 30px; color: #6B7280;">
        Sistema LUCREI
      </p>
    </div>
  `;

  for (const user of users) {
    if (user.role === 'OWNER' || user.role === 'ADMIN') {
      await sendEmail({ to: user.email, subject, html });
    }
  }
}
